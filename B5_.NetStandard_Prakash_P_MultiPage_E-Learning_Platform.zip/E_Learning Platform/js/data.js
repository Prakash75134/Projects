const courseCatalog = [
    { id: "html", title: "HTML5 Layouts", url: "https://www.youtube.com/embed/qz0aGYrrlhU" },
    { id: "css", title: "Advanced CSS Grid", url: "https://www.youtube.com/embed/yfoY53QXEnI" },
    { id: "js", title: "JavaScript ES6+", url: "https://www.youtube.com/embed/W6NZfCO5SIk" },
    { id: "bs", title: "Bootstrap 5 Components", url: "https://www.youtube.com/embed/4sosXZsdy-s" },
    { id: "jq", title: "jQuery DOM Logic", url: "https://www.youtube.com/embed/hMxGhHNOkCU" },
    { id: "cs", title: "C# Programming", url: "https://www.youtube.com/embed/GhQdlIFylQ8" },
    { id: "net", title: ".NET Core Framework", url: "https://www.youtube.com/embed/C5cnZ-gZy2I" },
    { id: "py", title: "Python for Beginners", url: "https://www.youtube.com/embed/rfscVS0vtbw" }
];

const quizBank = [
    { q: "Which tag is used for a dropdown list?", options: ["&lt;input&gt;", "&lt;select&gt;", "&lt;list&gt;", "&lt;dropdown&gt;"], a: "&lt;select&gt;" },
    { q: "Which CSS property adds space inside an element?", options: ["margin", "border", "padding", "spacing"], a: "padding" },
    { q: "How do you write a comment in jQuery?", options: ["//", "/* */", "&lt;!-- --&gt;", "Both 1 and 2"], a: "Both 1 and 2" },
    { q: "In C#, which keyword prevents class inheritance?", options: ["final", "static", "sealed", "private"], a: "sealed" },
    { q: "Which .NET component executes code?", options: ["CLR", "MSIL", "CTS", "CLS"], a: "CLR" },
    { q: "What is the file extension for Python?", options: [".py", ".pyt", ".ptl", ".pyc"], a: ".py" },
    { q: "Which Bootstrap class centers text?", options: ["text-center", "align-center", "middle", "center-text"], a: "text-center" },
    { q: "Which JS method converts a string to an integer?", options: ["parseInt()", "toString()", "toInteger()", "Number()"], a: "parseInt()" },
    { q: "Which jQuery method hides an element with a fade?", options: ["hide()", "fadeOut()", "invisible()", "remove()"], a: "fadeOut()" },
    { q: "How do you start a for loop in Python?", options: ["for x in y:", "for x to y", "foreach x in y", "loop x in y"], a: "for x in y:" }
];
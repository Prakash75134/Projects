let timeLeft = 7 * 60; // 7 Minutes
let timer;

function startTimer() {
    timer = setInterval(() => {
        let mins = Math.floor(timeLeft / 60);
        let secs = timeLeft % 60;
        const display = document.getElementById('timer-display');
        if(display) {
            display.innerText = `${mins}:${secs < 10 ? '0' : ''}${secs}`;
        }
        if (timeLeft <= 0) {
            clearInterval(timer);
            alert("Time is up!");
            submitExam();
        }
        timeLeft--;
    }, 1000);
}

async function initQuiz() {
    const qArea = document.getElementById('qArea');
    if(!qArea) return;

    qArea.innerHTML = "<div class='text-center p-5'><h4>Loading Assessment...</h4></div>";
    
    // Simulating Async Load
    await new Promise(r => setTimeout(r, 500));
    qArea.innerHTML = "";

    quizBank.forEach((item, i) => {
        const questionDiv = document.createElement('div');
        questionDiv.className = "course-box mb-4 shadow-sm p-4 bg-white rounded";
        
        let optionsHTML = item.options.map(opt => `
            <div class="form-check my-2">
                <input class="form-check-input" type="radio" name="q${i}" value="${opt}" id="q${i}${opt}">
                <label class="form-check-label" for="q${i}${opt}">${opt}</label>
            </div>
        `).join('');

        questionDiv.innerHTML = `
            <p class="h5 mb-3"><strong>${i + 1}. ${item.q}</strong></p>
            ${optionsHTML}
        `;
        qArea.appendChild(questionDiv);
    });
    startTimer();
}

function submitExam() {
    clearInterval(timer);
    let score = 0;
    quizBank.forEach((item, i) => {
        const checked = document.querySelector(`input[name="q${i}"]:checked`);
        if (checked && checked.value === item.a) {
            score++;
        }
    });
    const finalScore = (score / quizBank.length) * 100;
    localStorage.setItem("final_score", finalScore);
    window.location.href = "profile.html";
}

document.addEventListener("DOMContentLoaded", initQuiz);
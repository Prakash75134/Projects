// Function to determine Grade based on percentage
function getGrade(percent) {
    if (percent >= 90) return "A+";
    if (percent >= 80) return "A";
    if (percent >= 70) return "B";
    if (percent >= 60) return "C";
    return "F";
}

// Function to calculate percentage
function calculatePercentage(score, total) {
    if (total === 0) return 0;
    return Math.round((score / total) * 100);
}

// Export for Jest
if (typeof module !== "undefined") {
    module.exports = { calculatePercentage, getGrade };
}
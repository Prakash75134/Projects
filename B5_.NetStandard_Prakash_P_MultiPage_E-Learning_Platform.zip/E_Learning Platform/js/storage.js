const StorageHelper = {
    initializeProgress() {
        const courseNames = ["HTML", "CSS", "JavaScript"];
        courseNames.forEach(name => {
            if (localStorage.getItem(name + "_video") === null) {
                localStorage.setItem(name + "_video", "false");
            }
            if (localStorage.getItem(name + "_quiz") === null) {
                localStorage.setItem(name + "_quiz", "false");
            }
        });

        if (localStorage.getItem("score") === null) localStorage.setItem("score", "0");
        if (localStorage.getItem("grade") === null) localStorage.setItem("grade", "-");
        if (localStorage.getItem("feedback") === null) localStorage.setItem("feedback", "Not Attempted");
    },

    getCourseProgress(courseName) {
        const videoDone = localStorage.getItem(courseName + "_video") === "true";
        const quizDone = localStorage.getItem(courseName + "_quiz") === "true";
        let progress = 0;
        if (videoDone) progress += 50;
        if (quizDone) progress += 50;
        return progress;
    },

    markVideoWatched(courseName) {
        localStorage.setItem(courseName + "_video", "true");
        alert(courseName + " video marked as watched!");
        location.reload(); 
    }
};

// Initialize automatically
StorageHelper.initializeProgress();
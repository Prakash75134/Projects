const { calculatePercentage, getGrade, hasPassed } = require("../js/app");

// Test 1: Percentage Calculation
test("Should calculate 8 out of 10 as 80 percent", () => {
    expect(calculatePercentage(8, 10)).toBe(80);
});

// Test 2: Grade Logic
test("Should return Grade A for 85 percent", () => {
    expect(getGrade(85)).toBe("A");
});

// Test 3: Pass/Fail Logic
test("Should return false for a score of 40 percent", () => {
    expect(hasPassed(40)).toBe(false);
});